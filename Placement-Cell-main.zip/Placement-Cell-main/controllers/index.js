const employeeController = require("./employeeController");
const studentController = require("./studentController");
const interviewController = require("./interviewController");

module.exports = { employeeController, studentController, interviewController };
