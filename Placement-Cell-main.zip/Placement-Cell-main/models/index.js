const Employee = require("./employee");
const Interview = require("./interview");
const Student = require("./student");
module.exports = {
  Employee,
  Interview,
  Student,
};
