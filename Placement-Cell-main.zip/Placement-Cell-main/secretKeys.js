const SESSION_SECRET_KEY = "thisISaDUmmySECRET!!Key";

module.exports = { SESSION_SECRET_KEY };
